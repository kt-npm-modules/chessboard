import { Color } from '../state/board/types';
import { createRenderGeometry } from './geometry/factory';
import { LayoutInternal } from './types';

export function layoutRefreshGeometry(
	state: LayoutInternal,
	container: HTMLElement,
	orientation: Color
): boolean {
	const newBoardSize = Math.min(container.clientWidth, container.clientHeight);
	const changed = [
		newBoardSize !== state.boardSize,
		orientation !== state.geometry?.orientation
	].some(Boolean);
	if (changed) {
		state.boardSize = newBoardSize;
		state.layoutVersion++;
		state.geometry = createRenderGeometry(newBoardSize, orientation);
	}
	return changed;
}

export function layoutRefreshGeometryForOrientation(
	state: LayoutInternal,
	orientation: Color
): boolean {
	if (orientation !== state.geometry?.orientation) {
		state.layoutVersion++;
		state.geometry = createRenderGeometry(state.boardSize, orientation);
		return true;
	}
	return false;
}
